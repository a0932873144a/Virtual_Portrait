using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System.Diagnostics;

public class externalScriptCaller : MonoBehaviour
{
    private string path;
    private System.Diagnostics.Process process;
    public bool isReady{
        get;
        private set;
    } = false;
    // Start is called before the first frame update

    void Start()
    {
        path = Directory.GetCurrentDirectory();
        UnityEngine.Debug.Log(path);
        string strCmdText;
        strCmdText= "pip3 install -r requirements.txt & python main.py & pause";
        process = new System.Diagnostics.Process();
        System.Diagnostics.ProcessStartInfo startInfo = new System.Diagnostics.ProcessStartInfo();
        startInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Hidden;
        startInfo.FileName = "cmd.exe";
        startInfo.Arguments = strCmdText;
        process.StartInfo = startInfo;
        process.Start();
        isReady = true;
    }

    public string getCmdOutput(){
        return "no lol";
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnApplicationQuit(){
        File.Delete("piplog.txt");
        process.Kill();
    }
}
