using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controller : MonoBehaviour
{
    private Animator m_animator;

    // Start is called before the first frame update
    void Start()
    {
        m_animator = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.A))
        {
            if (m_animator != null)
            {
                // play Bounce but start at a quarter of the way though
                //anim.Play("Base Layer.Bounce", 0, 0.25f);
                m_animator.SetInteger("magic", 1);

            }
        }

        if (Input.GetKeyDown(KeyCode.B))
        {
            if (m_animator != null)
            {
                m_animator.SetInteger("magic", 2);
            }
        }

        if (Input.GetKeyDown(KeyCode.C))
        {
            if (m_animator != null)
            {
                m_animator.SetInteger("magic", 3);
            }
        }

        if (Input.GetKeyDown(KeyCode.D))
        {
            if (m_animator != null)
            {
                m_animator.SetInteger("magic", 4);
            }
        }

        if (Input.GetKeyDown(KeyCode.E))
        {
            if (m_animator != null)
            {
                m_animator.SetInteger("magic", 5);
            }
        }

        if (Input.GetKeyDown(KeyCode.F))
        {
            if (m_animator != null)
            {
                m_animator.SetInteger("magic", 6);
            }
        }

        if (Input.GetKeyDown(KeyCode.G))
        {
            if (m_animator != null)
            {
                m_animator.SetInteger("magic", 7);
            }
        }

        if (Input.GetKeyDown(KeyCode.H))
        {
            if (m_animator != null)
            {
                m_animator.SetInteger("magic", 8);
            }
   
        }

        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (m_animator != null)
            {
                m_animator.SetInteger("magic",0);
            }
        }

    }
}
