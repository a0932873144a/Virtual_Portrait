using Live2D.Cubism.Framework.LookAt;
using UnityEngine;
using System.Collections.Generic;
using System.Net.Sockets;
using Newtonsoft.Json;
using System.Linq;

public class CubismLookTarget : MonoBehaviour, ICubismLookTarget
{
    private class CenterPoint
    {
        public float x { get; set; }
        public float y { get; set; }
    }

    private ServerThread st;

    private Vector3 targetPosition;

    private void Start()
    {
        targetPosition = new Vector3(0, 0, 0);

        //開始連線，設定使用網路、串流、TCP
        st = new ServerThread(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp, "127.0.0.1", 8787);
        st.Listen();//讓Server socket開始監聽連線
        st.StartConnect();//開啟Server socket

    }

    public Vector3 GetPosition()
    {
        if (st.receiveMessage != null)
        {
            string json_str = st.receiveMessage;

            CenterPoint centerPoint = JsonConvert.DeserializeObject<CenterPoint>(json_str);

            targetPosition = new Vector3(centerPoint.x, centerPoint.y, 0.0f);

            Debug.Log($"targetPosition x: {targetPosition.x}, y: {targetPosition.y}");

            st.receiveMessage = null;
        }

        st.Receive();

        return targetPosition;
    }


    public bool IsActive()
    {
        return true;
    }

    private void OnApplicationQuit()//應用程式結束時自動關閉連線
    {
        st.StopConnect();
    }
}